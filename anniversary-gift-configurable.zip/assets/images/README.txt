Add Canva-edited JPG or PNG images here. The default photo timeline paths are 01.jpg through 09.jpg; update the matching photo paths in gift-config.js if you use different names or extensions.
